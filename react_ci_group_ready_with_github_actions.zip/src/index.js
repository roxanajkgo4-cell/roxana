import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Accueil from "./Pages/Accueil";
import NosServices from "./Pages/NosServices";
import NosPacks from "./Pages/NosPacks";
import NotreExpertise from "./Pages/NotreExpertise";
import APropos from "./Pages/APropos";
import Contact from "./Pages/Contact";
import MentionsLegales from "./Pages/MentionsLegales";
import PolitiqueConfidentialite from "./Pages/PolitiqueConfidentialite";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Router>
    <Routes>
      <Route path="/" element={<Accueil />} />
      <Route path="/NosServices" element={<NosServices />} />
      <Route path="/NosPacks" element={<NosPacks />} />
      <Route path="/NotreExpertise" element={<NotreExpertise />} />
      <Route path="/APropos" element={<APropos />} />
      <Route path="/Contact" element={<Contact />} />
      <Route path="/MentionsLegales" element={<MentionsLegales />} />
      <Route path="/PolitiqueConfidentialite" element={<PolitiqueConfidentialite />} />
    </Routes>
  </Router>
);